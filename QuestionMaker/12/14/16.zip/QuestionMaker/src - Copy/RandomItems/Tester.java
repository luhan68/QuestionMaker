/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package RandomItems;

/**
 *
 * @author gene
 */
public class Tester {
    
    public static void main (String [] args){
        
        CreateImageFromBase bs = new CreateImageFromBase();
        bs.Create("Apples", 5, "Apples", 5, true, false);
        
    }
    
    
    
}
