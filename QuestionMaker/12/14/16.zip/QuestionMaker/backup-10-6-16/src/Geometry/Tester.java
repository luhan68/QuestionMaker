/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Geometry;

/**
 *
 * @author Gene
 */
public class Tester {
    public static void main(String [] args){
        ClockCreater clock = new ClockCreater();
        clock.clock_maker("clock.png", 5, 30, 50);
        
       // DrawImages test = new DrawImages();
     //   test.Draw("", "test", true, false, false);
        
        
 //       RulerCreater cr = new RulerCreater();
 //       cr.drawRuler("ruler.png", 1 , 32); // try 3/4 inch
    }
    
    
}
