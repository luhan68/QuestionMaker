/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package questionmaker;

import algorithms.Fractions.Level5_6.WordProbMinusWithin20;
import algorithms.Algebra.Level1_2.WordProbAnimalsAdd_1_2;
import algorithms.Algebra.Level1_2.WordProb_Money_Level_1_2;
import algorithms.Algebra.Level1_3.A_PLUS_B_PLUS_C;
import algorithms.Algebra.Level1_3.A_Plus_blank_equal_c;
import algorithms.Algebra.Level1_4.A_Minus_BLANK_Equals_C;
import algorithms.Algebra.Level1_5.Start_AT_x_CountDown_By_Y_1_5_Alg;
import algorithms.Algebra.Level1_5.Start_At_x_CountUP_Y;
import algorithms.Algebra.Level1_6.Related_Facts_1_6_alg;
import algorithms.Algebra.Level1_6.a_minus_b_equals_c_lvl_1_6_alg;
import algorithms.Algebra.Level1_6.a_plus_b_equals_c_lvl_1_6_Alg;
import algorithms.Algebra.Level1_7.Which_Statement_True_Add_lvl_1_7;
import algorithms.Algebra.Level1_8.C_equals_A_Plus_Blank_1_8_alg;
import algorithms.Algebra.Level1_8.A_minus_BLANK_equals_C_alg_1_8;
import algorithms.Algebra.Level2_1.Alg_WordProblems_lvl2_1;
import algorithms.Algebra.Level2_2.A_Plus_b_equals_c_Alg_2_2;
import algorithms.Algebra.Level2_2.a_minus_blank_equals_c_Alg_2_2;
import algorithms.Algebra.Level2_2.blank_plus_b_equals_c_Alg_2_2;
import algorithms.Algebra.Level2_3.Alg_which_number_odd_even_2_3;
import algorithms.Algebra.Level2_3.Which_Number_Even_2_3;
import algorithms.Algebra.Level2_3.Number_Between_Alg_2_3;
import algorithms.Algebra.Level3_1.how_many_rows_of_numbers_alg_3_1;
import algorithms.Algebra.Level3_1.which_number_sentence_alg_3_1;
import algorithms.Algebra.Level3_2.WordProb_division_Alg_3_2;
import algorithms.Algebra.Level3_4.a_equals_b_dividedby_blank_alg_3_4;
import algorithms.Algebra.Level3_4.blank_times_b_equals_alg_3_4;
import algorithms.Algebra.Level3_5.commutative_multiplication_alg_3_5;
import algorithms.Algebra.Level3_5.associative_with_multiplication_alg_3_5;
import algorithms.Algebra.Level3_6.blank_times_b_equals_c_alg_3_6;
import algorithms.Algebra.Level3_6.blank_groups_of_b_equals_c_alg_3_6;
import algorithms.Algebra.Level3_7.a_dividedby_b_within100_alg_3_7;
import algorithms.Algebra.Level3_7.a_times_b_equals_alg_3_7;
import algorithms.Algebra.Level3_8.WordProblemPetStore_3_8;
import algorithms.Algebra.Level3_9.InOutMultiply_3_9;
import algorithms.Algebra.Level3_9.InOutPlus_3_9;
import algorithms.Algebra.Level4_1.a_times_asManyAs_b_alg_4_1;
import algorithms.Algebra.Level4_2.WordProblemMoneyMultiply_4_2;
import algorithms.Algebra.Level4_3.Money_WordProblem_multiStep;
import algorithms.Algebra.Level4_4.which_is_a_factor_of_alg_4_4;
import algorithms.Algebra.Level4_5.sequence_of_numbers_alg_4_5;
import algorithms.Algebra.Level5_0.MultiStepMath;
import algorithms.Algebra.Level5_2.MultiStepMath5_2;
import algorithms.Base10.Level1_1.Base10_1_2_3_space_lvl_1_1;
import algorithms.Base10.Level1_3.WhichTrue_Greater_Less;
import algorithms.Base10.Level1_4.A_Plus_b_equals_c_Base10_Lvl_1_4;
import algorithms.Base10.Level1_5.WhatisXMoreThanY_lvl_1_5_Base10;
import algorithms.Base10.Level1_6.SubtractMultiplesOfTen_BASE10_1_6;
import algorithms.Base10.Level2_2.count_456_457_blank_Base10_2_2;
import algorithms.Base10.Level2_2.count_246_blank_446_base10_2_2;
import algorithms.Base10.Level2_2.count_230_blank_250_base10_2_2;
import algorithms.Base10.Level2_2.count_330_335_blank_base10_2_2;
import algorithms.Base10.Level2_4.blank_greater_than_b_base10_2_4;
import algorithms.Base10.Level2_5.a_plus_b_equals_blank_Base10_2_5;
import algorithms.Base10.Level2_5.a_minus_b_equals_blank_base10_2_5;
import algorithms.Base10.Level2_6.a_plus_b_plus_c_Base10_2_6;
import algorithms.Base10.Level2_6.a_plus_b_plus_c_plus_d_base10_2_6;
import algorithms.Base10.Level2_7.a_plus_b_within_1000_base10_2_7;
import algorithms.Base10.Level2_7.a_minus_b_within_1000_base10_2_7;
import algorithms.Base10.Level2_8.minus_10_or_100_base10_2_8;
import algorithms.Base10.Level2_8.plus_10_or100_base10_2_8;
import algorithms.Base10.Level2_9.if_then_a_plus_blank_equals_c_base10_2_9;
import algorithms.Base10.Level2_9.if_then_a_minus_blank_equals_c_base10_2_9;
import algorithms.Base10.Level2_9.fact_family_within_100_base10_2_9;
import algorithms.Base10.Level3_1.Round_to_nearest_10_base10_3_1;
import algorithms.Base10.Level3_1.Round_to_nearest_100_base10_3_1;
import algorithms.Base10.Level3_2.a_plus_b_within_thousand_base10_3_2;
import algorithms.Base10.Level3_2.a_minus_b_within_thousand_base10_3_2;
import algorithms.Base10.Level3_3.a_times_b_10_to_90_base10_3_3;
import algorithms.Base10.Level5_3.WriteOutHundredsPlace;
import algorithms.Base10.Level5_3.WriteOutThousandsPlace;
import algorithms.Legacy.AdditionXToY;
import algorithms.Legacy.DivideXbyY;
import algorithms.Legacy.MultiplyXbyY;
import algorithms.Legacy.SubtractionXtoY;
import algorithms.Counting.Level1_1.abc1_1;
import algorithms.Counting.Level1_1.startatxcountdownbyy1;
import algorithms.Counting.Level1_2.startatxcountdownbyy1_1_2;
import algorithms.Counting.Level1_1.startatxcountupbyy;
import algorithms.Counting.Level1_2.startatxcountupbyy1_1_2;
import algorithms.Counting.Level1_1.x_plus_space_equals_y;
import algorithms.Counting.Level1_2.x_plus_space_equals_y_1_2;
import algorithms.Counting.Level1_1.x_plus_y_equal_z_so_z_minus_space_equals_blank;
import algorithms.Counting.Level1_3.counting_1_2_3_space_lvel_1_3;
import algorithms.Counting.Level1_3.counting_1_2_space_3_lvel_1_3;
import algorithms.Counting.Level1_4.Blank_LESSTHAN_X;
import algorithms.Counting.Level1_4.z_equals_x_plus_space;
import algorithms.Counting.Level1_5.X_LESS_THAN_Y;
import algorithms.Counting.Level1_5.X_MORE_THAN_Y;
import algorithms.Counting.Level1_5.abc1_5;
import algorithms.Counting.Level1_5.abc_Subtract_1_5;
import java.io.PrintWriter;
import java.util.StringTokenizer;
import java.util.Vector;
import javax.swing.DefaultComboBoxModel;

/**
 *
 * @author Gene
 */
public class MainForm extends javax.swing.JFrame {

    public String algorithm = "";
    String sqlcode = "";
    int qzid = 0;

    public MainForm() {
        initComponents();
        LoadOptions();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        algoselect = new javax.swing.JComboBox();
        jPanel3 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        level_select = new javax.swing.JComboBox();
        jLabel5 = new javax.swing.JLabel();
        question_sel = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        Hint = new javax.swing.JComboBox();
        jPanel4 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        savelocation = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        quizid = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setText("Question Maker ");

        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), " Algorithm "));

        jLabel4.setText("Select A Question Type Algorithm:");

        algoselect.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "addition 1 - 10", "subtraction 1 - 10", "addition 1 - 100", "subtraction 1 - 10", "subtraction 1 - 100", "multiply 1 - 10", "1+2+3=?", "2+_=12", "2+9=11 11-_=9", "start@xandcountupbyy", "start at x and count down by y", "1+2+3=? lvl_1_2" }));

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(algoselect, javax.swing.GroupLayout.PREFERRED_SIZE, 328, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(algoselect, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(25, Short.MAX_VALUE))
        );

        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), " Question Configuration "));

        jLabel3.setText("Level:");

        level_select.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "0.1", "0.2", "0.2", "0.3", "0.4", "0.5", "0.6", "0.7", "0.8", "0.9", "1.0", "1.1", "1.2", "1.3", "1.4", "1.5", "1.6", "1.7", "1.8", "1.9", "2.0" }));

        jLabel5.setText("Hint:");

        jLabel6.setText("Number Of Questions:");

        Hint.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Algorithm Generated" }));

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 58, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(level_select, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(question_sel))
                    .addComponent(Hint, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(level_select, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(question_sel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(Hint, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        jPanel4.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true), " Generate Questions "));

        jLabel7.setText("Save Results To: ");

        savelocation.setText("C:\\Users\\gene\\Desktop\\sqlcode\\test.sql");
        savelocation.setToolTipText("");
        savelocation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                savelocationActionPerformed(evt);
            }
        });

        jButton1.setText("Generate");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel8.setText("Next QID:");

        quizid.setText("38");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(quizid))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(savelocation, javax.swing.GroupLayout.PREFERRED_SIZE, 315, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(jButton1)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(quizid, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(11, 11, 11)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(savelocation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 0, Short.MAX_VALUE)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(182, 182, 182)
                        .addComponent(jLabel1))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        algorithm = algoselect.getSelectedItem().toString();
        String level = level_select.getSelectedItem().toString();
        int numquestions = Integer.parseInt(question_sel.getText());
        String hint = Hint.getSelectedItem().toString();
        String SaveLocation = savelocation.getText();
        LoadAlgorithms(algorithm, level, numquestions, hint, SaveLocation);

    }//GEN-LAST:event_jButton1ActionPerformed

    private void savelocationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_savelocationActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_savelocationActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(MainForm.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainForm().setVisible(true);
            }
        });
    }

    public void LoadAlgorithms(String algo, String level, int numquestions, String hint, String SaveLocation) {
        Vector questions = new Vector();
        for (int i = 0; i < numquestions; i++) { //loop through and process questions one at a time 
            Vector RawQuestions = ChooseAlgorithm(algo, level, hint);

            //when raw questions are returned (with mixed in answers) we must add hint and level to the vector
            questions.addElement(RawQuestions);

        }
        System.out.println(questions);

        //Save The Questions
        Save(SaveLocation, questions);

    }

    public Vector ChooseAlgorithm(String algo, String level, String hint) {
        Vector results = new Vector();
        //run the algorithm

        /*subject index 
         1 = Math
               
         */
        if (algo.equals("addition 1 - 10")) {
            AdditionXToY add = new AdditionXToY();
            results = add.AddToX(1, 10, hint, level);
            results.addElement("1");
            results.addElement("Addition");
        } else if (algo.equals("addition 1 - 100")) {
            AdditionXToY add = new AdditionXToY();
            results = add.AddToX(1, 100, hint, level);
            results.addElement("1");
            results.addElement("Addition");
        } else if (algo.equals("subtraction 1 - 10")) {
            SubtractionXtoY subtract = new SubtractionXtoY();
            results = subtract.SubtractXfromY(1, 100, hint, level);
            results.addElement("1");
            results.addElement("Subtraction");
        } else if (algo.contains("subtraction 1 - 100")) {
            SubtractionXtoY subtract = new SubtractionXtoY();
            results = subtract.SubtractXfromY(1, 100, hint, level);
        } else if (algo.equals("multiply 1 - 10")) {
            MultiplyXbyY mult = new MultiplyXbyY();
            results = mult.Multiply(1, 10, hint, level);
            results.addElement("1");
            results.addElement("Multiplication");
        } else if (algo.equals("multiply 1 - 100")) {
            MultiplyXbyY mult = new MultiplyXbyY();
            results = mult.Multiply(1, 100, hint, level);
            results.addElement("1");
            results.addElement("Multiplication");
        } else if (algo.equals("divide 1 - 10")) {
            DivideXbyY div = new DivideXbyY();
            results = div.Divide(1, 10, hint, level);
            results.addElement("1");
            results.addElement("Division");
        } else if (algo.equals("1+2+3=?")) {
            abc1_1 add = new abc1_1();
            results = add.AddToX(1, 20, hint, "1.1");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("2+_=12")) {
            x_plus_space_equals_y add = new x_plus_space_equals_y();
            results = add.generate(1, 20, hint, "1.1");
            results.addElement("1");
            results.addElement("x_plus_space_equals_y");
        } else if (algo.equals("2+9=11 11-_=9")) {
            x_plus_y_equal_z_so_z_minus_space_equals_blank add = new x_plus_y_equal_z_so_z_minus_space_equals_blank();
            results = add.generate(10, 40, hint, "1.2");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("start@xandcountupbyy")) {
            startatxcountupbyy add = new startatxcountupbyy();
            results = add.generate(10, 40, hint, "1.1");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("start at x and count down by y")) {
            startatxcountdownbyy1 add = new startatxcountdownbyy1();
            results = add.generate(10, 40, hint, "1.1");
            results.addElement("1");
            results.addElement("abc");
        } //start level 1.2 counting
        else if (algo.equals("1+2+3=? lvl_1_2")) {
            abc1_1 add = new abc1_1();
            results = add.AddToX(10, 40, hint, "1.2");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("2+_=12 lvl_1_2")) {
            x_plus_space_equals_y_1_2 add = new x_plus_space_equals_y_1_2();
            results = add.generate(10, 40, hint, "1.2");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("start@xandcountupbyy_lvl_1_2")) {
            startatxcountupbyy1_1_2 add = new startatxcountupbyy1_1_2();
            results = add.generate(10, 20, hint, "1.2");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("start at x and count down by y_lvl_1_2")) {
            startatxcountdownbyy1_1_2 add = new startatxcountdownbyy1_1_2();
            results = add.generate(10, 20, hint, "1.2");
            results.addElement("1");
            results.addElement("abc");
            //start level 1.3 counting
        } else if (algo.equals("67,68,69,_")) {
            counting_1_2_3_space_lvel_1_3 add = new counting_1_2_3_space_lvel_1_3();
            results = add.generate(10, 20, hint, "1.3");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("67,_,69,70")) {
            counting_1_2_space_3_lvel_1_3 add = new counting_1_2_space_3_lvel_1_3();
            results = add.generate(10, 20, hint, "1.3");
            results.addElement("1");
            results.addElement("abc");
        } //start level 1.4 counting
        else if (algo.equals("15=10+_")) {
            z_equals_x_plus_space add = new z_equals_x_plus_space();
            results = add.generate(10, 20, hint, "1.4");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("_<X")) {
            Blank_LESSTHAN_X add = new Blank_LESSTHAN_X();
            results = add.generate(10, 100, hint, "1.4");
            results.addElement("1");
            results.addElement("abc");
        } //start level 1.5 counting
        else if (algo.equals("72+20=?_level_1.5")) {
            abc1_5 add = new abc1_5();
            results = add.generate(20, 100, hint, "1.5");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("What is x less than y?")) {
            X_LESS_THAN_Y add = new X_LESS_THAN_Y();
            results = add.generate(20, 100, hint, "1.5");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("What is x more than y?")) {
            X_MORE_THAN_Y add = new X_MORE_THAN_Y();
            results = add.generate(20, 100, hint, "1.5");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("x-y=?_level_1_5")) {
            abc_Subtract_1_5 add = new abc_Subtract_1_5();
            results = add.generate(20, 100, hint, "1.5");
            results.addElement("1");
            results.addElement("abc");
        } // Start Algebra 1.1
        else if (algo.equals("WordProb_Within20")) {
            WordProbAnimalsAdd_1_2 add = new WordProbAnimalsAdd_1_2();
            results = add.generate(1, 10, hint, "1.1");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("WordProbMinusWithin20")) {
            WordProbMinusWithin20 add = new WordProbMinusWithin20();
            results = add.generate(1, 10, hint, "1.1");
            results.addElement("1");
            results.addElement("abc");
        } //Algebra 1.2
        else if (algo.equals("WordProbAnimalsAdd_1_2")) {
            WordProbAnimalsAdd_1_2 add = new WordProbAnimalsAdd_1_2();
            results = add.generate(1, 10, hint, "1.2");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("WordProb_Money_Level_1_2")) {
            WordProb_Money_Level_1_2 add = new WordProb_Money_Level_1_2();
            results = add.generate(1, 10, hint, "1.2");
            results.addElement("1");
            results.addElement("abc");
        } //1.3 Algebra
        else if (algo.equals("A_PLUS_B_PLUS_C")) {
            A_PLUS_B_PLUS_C add = new A_PLUS_B_PLUS_C();
            results = add.generate(1, 20, hint, "1.3");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("A_Plus_blank_equal_c")) {
            A_Plus_blank_equal_c add = new A_Plus_blank_equal_c();
            results = add.generate(1, 20, hint, "1.3");
            results.addElement("1");
            results.addElement("abc");
            //1.4 Algebra
        } else if (algo.equals("A_Minus_BLANK_Equals_C")) {
            A_Minus_BLANK_Equals_C add = new A_Minus_BLANK_Equals_C();
            results = add.generate(1, 20, hint, "1.4");
            results.addElement("1");
            results.addElement("abc");
        } //1.5 Algebra
        else if (algo.equals("Start_At_x_CountUP_Y")) {
            Start_At_x_CountUP_Y add = new Start_At_x_CountUP_Y();
            results = add.generate(1, 20, hint, "1.5");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("Start_AT_x_CountDown_By_Y_1_5_Alg")) {
            Start_AT_x_CountDown_By_Y_1_5_Alg add = new Start_AT_x_CountDown_By_Y_1_5_Alg();
            results = add.generate(1, 20, hint, "1.5");
            results.addElement("1");
            results.addElement("abc");
        } //1.6 Algebra
        else if (algo.equals("a_plus_b_equals_c_lvl_1_6_Alg")) {
            a_plus_b_equals_c_lvl_1_6_Alg add = new a_plus_b_equals_c_lvl_1_6_Alg();
            results = add.generate(1, 20, hint, "1.6");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("a_minus_b_equals_c_lvl_1_6_alg")) {
            a_minus_b_equals_c_lvl_1_6_alg add = new a_minus_b_equals_c_lvl_1_6_alg();
            results = add.generate(1, 20, hint, "1.6");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("Related_Facts_1_6_alg")) {
            Related_Facts_1_6_alg add = new Related_Facts_1_6_alg();
            results = add.generate(1, 20, hint, "1.6");
            results.addElement("1");
            results.addElement("abc");
            //1.7 algebra
        } else if (algo.equals("Which_Statement_True_Add_lvl_1_7")) {
            Which_Statement_True_Add_lvl_1_7 add = new Which_Statement_True_Add_lvl_1_7();
            results = add.generate(1, 20, hint, "1.7");
            results.addElement("1");
            results.addElement("abc");
            //1.8 algebra
        } else if (algo.equals("C_equals_A_Plus_Blank_1_8_alg")) {
            C_equals_A_Plus_Blank_1_8_alg add = new C_equals_A_Plus_Blank_1_8_alg();
            results = add.generate(1, 20, hint, "1.8");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("A_minus_BLANK_equals_C_alg_1_8")) {
            A_minus_BLANK_equals_C_alg_1_8 add = new A_minus_BLANK_equals_C_alg_1_8();
            results = add.generate(1, 20, hint, "1.8");
            results.addElement("1");
            results.addElement("abc");
        } //Start Base 10 Level 1.1
        else if (algo.equals("Base10_1_2_3_space_lvl_1_1")) {
            Base10_1_2_3_space_lvl_1_1 add = new Base10_1_2_3_space_lvl_1_1();
            results = add.generate(1, 20, hint, "1.1");
            results.addElement("1");
            results.addElement("abc");
            //base 10 Level 1.3
        } else if (algo.equals("WhichTrue_Greater_Less")) {
            WhichTrue_Greater_Less add = new WhichTrue_Greater_Less();
            results = add.generate(1, 20, hint, "1.3");
            results.addElement("1");
            results.addElement("abc");
        } //Base 10 Level 1.4
        else if (algo.equals("A_Plus_b_equals_c_Base10_Lvl_1_4")) {
            A_Plus_b_equals_c_Base10_Lvl_1_4 add = new A_Plus_b_equals_c_Base10_Lvl_1_4();
            results = add.generate(10, 100, hint, "1.4");
            results.addElement("1");
            results.addElement("abc");
        } //Base 10 Level 1.5
        else if (algo.equals("WhatisXMoreThanY_lvl_1_5_Base10")) {
            WhatisXMoreThanY_lvl_1_5_Base10 add = new WhatisXMoreThanY_lvl_1_5_Base10();
            results = add.generate(1, 100, hint, "1.5");
            results.addElement("1");
            results.addElement("abc");
        }//Base 10 Level 1.6
        else if (algo.equals("SubtractMultiplesOfTen_BASE10_1_6")) {
            SubtractMultiplesOfTen_BASE10_1_6 add = new SubtractMultiplesOfTen_BASE10_1_6();
            results = add.generate(10, 100, hint, "1.6");
            results.addElement("1");
            results.addElement("abc");
        } // *************************  LEVEL 2 *******************************************
        //Algebra Level 2.1
        else if (algo.equals("Alg_WordProblems_lvl2_1")) {
            Alg_WordProblems_lvl2_1 add = new Alg_WordProblems_lvl2_1();
            results = add.generate(1, 100, hint, "2.1");
            results.addElement("1");
            results.addElement("abc");
        } //Algebra Level 2.2
        else if (algo.equals("A_Plus_b_equals_c_Alg_2_2")) {
            A_Plus_b_equals_c_Alg_2_2 add = new A_Plus_b_equals_c_Alg_2_2();
            results = add.generate(1, 20, hint, "2.2");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("a_minus_blank_equals_c_Alg_2_2")) {
            a_minus_blank_equals_c_Alg_2_2 add = new a_minus_blank_equals_c_Alg_2_2();
            results = add.generate(1, 20, hint, "2.2");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("blank_plus_b_equals_c_Alg_2_2")) {
            blank_plus_b_equals_c_Alg_2_2 add = new blank_plus_b_equals_c_Alg_2_2();
            results = add.generate(1, 20, hint, "2.2");
            results.addElement("1");
            results.addElement("abc");
        } //Algebra Level 2.3
        else if (algo.equals("Alg_which_number_odd_even_2_3")) { // Karl
            Alg_which_number_odd_even_2_3 add = new Alg_which_number_odd_even_2_3();
            results = add.generate(1, 20, hint, "2.3");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("Which_Number_Even_2_3")) { // Karl
            Which_Number_Even_2_3 add = new Which_Number_Even_2_3();
            results = add.generate(1, 20, hint, "2.3");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("Number_Between_Alg_2_3")) { // Karl
            Number_Between_Alg_2_3 add = new Number_Between_Alg_2_3();
            results = add.generate(1, 20, hint, "2.3");
            results.addElement("1");
            results.addElement("abc");
        } //Base10 level 2.2
        else if (algo.equals("count_456_457_blank_Base10_2_2")) { // Karl
            count_456_457_blank_Base10_2_2 add = new count_456_457_blank_Base10_2_2();
            results = add.generate(1, 1000, hint, "2.2");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("count_246_blank_446_base10_2_2")) { // Karl
            count_246_blank_446_base10_2_2 add = new count_246_blank_446_base10_2_2();
            results = add.generate(1, 1000, hint, "2.2");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("count_230_blank_250_base10_2_2")) { // Karl
            count_230_blank_250_base10_2_2 add = new count_230_blank_250_base10_2_2();
            results = add.generate(1, 1000, hint, "2.2");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("count_330_335_blank_base10_2_2")) { // Karl
            count_330_335_blank_base10_2_2 add = new count_330_335_blank_base10_2_2();
            results = add.generate(1, 1000, hint, "2.2");
            results.addElement("1");
            results.addElement("abc");
        } //Base10 Level 2.4
        else if (algo.equals("blank_greater_than_b_base10_2_4")) { // Karl
            blank_greater_than_b_base10_2_4 add = new blank_greater_than_b_base10_2_4();
            results = add.generate(100, 1000, hint, "2.4");
            results.addElement("1");
            results.addElement("abc");
        } //base10 level 2.5
        else if (algo.equals("a_plus_b_equals_blank_Base10_2_5")) { // Karl
            a_plus_b_equals_blank_Base10_2_5 add = new a_plus_b_equals_blank_Base10_2_5();
            results = add.generate(1, 100, hint, "2.5");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("a_minus_b_equals_blank_base10_2_5")) { // Karl
            a_minus_b_equals_blank_base10_2_5 add = new a_minus_b_equals_blank_base10_2_5();
            results = add.generate(1, 100, hint, "2.5");
            results.addElement("1");
            results.addElement("abc");
        } //base10 level 2.6
        else if (algo.equals("a_plus_b_plus_c_Base10_2_6")) { // Karl
            a_plus_b_plus_c_Base10_2_6 add = new a_plus_b_plus_c_Base10_2_6();
            results = add.generate(1, 100, hint, "2.6");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("a_plus_b_plus_c_plus_d_base10_2_6")) { // Karl
            a_plus_b_plus_c_plus_d_base10_2_6 add = new a_plus_b_plus_c_plus_d_base10_2_6();
            results = add.generate(1, 100, hint, "2.6");
            results.addElement("1");
            results.addElement("abc");
        } //base10 level 2.7
        else if (algo.equals("a_plus_b_within_1000_base10_2_7")) { // Karl
            a_plus_b_within_1000_base10_2_7 add = new a_plus_b_within_1000_base10_2_7();
            results = add.generate(1, 1000, hint, "2.7");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("a_minus_b_within_1000_base10_2_7")) { // Karl
            a_minus_b_within_1000_base10_2_7 add = new a_minus_b_within_1000_base10_2_7();
            results = add.generate(1, 1000, hint, "2.7");
            results.addElement("1");
            results.addElement("abc");
        } //base10 level 2.8
        else if (algo.equals("minus_10_or_100_base10_2_8")) { // Karl
            minus_10_or_100_base10_2_8 add = new minus_10_or_100_base10_2_8();
            results = add.generate(100, 900, hint, "2.8");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("plus_10_or100_base10_2_8")) { // Karl
            plus_10_or100_base10_2_8 add = new plus_10_or100_base10_2_8();
            results = add.generate(100, 900, hint, "2.8");
            results.addElement("1");
            results.addElement("abc");
        } //base10 level 2.9
        else if (algo.equals("if_then_a_plus_blank_equals_c_base10_2_9")) { // Karl
            if_then_a_plus_blank_equals_c_base10_2_9 add = new if_then_a_plus_blank_equals_c_base10_2_9();
            results = add.generate(1, 100, hint, "2.9");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("if_then_a_minus_blank_equals_c_base10_2_9")) { // Karl
            if_then_a_minus_blank_equals_c_base10_2_9 add = new if_then_a_minus_blank_equals_c_base10_2_9();
            results = add.generate(1, 100, hint, "2.9");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("fact_family_within_100_base10_2_9")) { // Karl
            fact_family_within_100_base10_2_9 add = new fact_family_within_100_base10_2_9();
            results = add.generate(1, 20, hint, "2.9");
            results.addElement("1");
            results.addElement("abc");
        } // *************************  LEVEL 3 *******************************************
        //Algebra Level 3.1
        else if (algo.equals("how_many_rows_of_numbers_alg_3_1")) { // Karl
            how_many_rows_of_numbers_alg_3_1 add = new how_many_rows_of_numbers_alg_3_1();
            results = add.generate(2, 8, hint, "3.1");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("which_number_sentence_alg_3_1")) { // Karl
            which_number_sentence_alg_3_1 add = new which_number_sentence_alg_3_1();
            results = add.generate(2, 8, hint, "3.1");
            results.addElement("1");
            results.addElement("abc");
        } //Algebra Level 3.2
        else if (algo.equals("WordProb_division_Alg_3_2")) { // Karl
            WordProb_division_Alg_3_2 add = new WordProb_division_Alg_3_2();
            results = add.generate(2, 100, hint, "3.2");
            results.addElement("1");
            results.addElement("abc");
        } //Algebra Level 3.4
        else if (algo.equals("blank_times_b_equals_alg_3_4")) { // Karl
            blank_times_b_equals_alg_3_4 add = new blank_times_b_equals_alg_3_4();
            results = add.generate(1, 90, hint, "3.4");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("a_equals_b_dividedby_blank_alg_3_4")) { // Karl
            a_equals_b_dividedby_blank_alg_3_4 add = new a_equals_b_dividedby_blank_alg_3_4();
            results = add.generate(1, 90, hint, "3.4");
            results.addElement("1");
            results.addElement("abc");
        } //algebra level 3.5
        else if (algo.equals("commutative_multiplication_alg_3_5")) { // Karl
            commutative_multiplication_alg_3_5 add = new commutative_multiplication_alg_3_5();
            results = add.generate(1, 90, hint, "3.5");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("associative_with_multiplication_alg_3_5")) { // Karl
            associative_with_multiplication_alg_3_5 add = new associative_with_multiplication_alg_3_5();
            results = add.generate(1, 90, hint, "3.5");
            results.addElement("1");
            results.addElement("abc");
        } //algebra level 3.6
        else if (algo.equals("blank_times_b_equals_c_alg_3_6")) { // Karl
            blank_times_b_equals_c_alg_3_6 add = new blank_times_b_equals_c_alg_3_6();
            results = add.generate(1, 90, hint, "3.6");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("blank_groups_of_b_equals_c_alg_3_6")) { // Karl
            blank_groups_of_b_equals_c_alg_3_6 add = new blank_groups_of_b_equals_c_alg_3_6();
            results = add.generate(1, 90, hint, "3.6");
            results.addElement("1");
            results.addElement("abc");
        } //algebra level 3.7
        else if (algo.equals("a_dividedby_b_within100_alg_3_7")) { // Karl
            a_dividedby_b_within100_alg_3_7 add = new a_dividedby_b_within100_alg_3_7();
            results = add.generate(1, 100, hint, "3.7");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("a_times_b_equals_alg_3_7")) { // Karl
            a_times_b_equals_alg_3_7 add = new a_times_b_equals_alg_3_7();
            results = add.generate(1, 100, hint, "3.7");
            results.addElement("1");
            results.addElement("abc");
        } //Base10 Level 3.1        
        else if (algo.equals("Round_to_nearest_10_base10_3_1")) { // Karl
            Round_to_nearest_10_base10_3_1 add = new Round_to_nearest_10_base10_3_1();
            results = add.generate(11, 89, hint, "3.1");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("Round_to_nearest_100_base10_3_1")) { // Karl
            Round_to_nearest_100_base10_3_1 add = new Round_to_nearest_100_base10_3_1();
            results = add.generate(101, 899, hint, "3.1");
            results.addElement("1");
            results.addElement("abc");
        } //Base10 Level 3.2        
        else if (algo.equals("a_plus_b_within_thousand_base10_3_2")) { // Karl
            a_plus_b_within_thousand_base10_3_2 add = new a_plus_b_within_thousand_base10_3_2();
            results = add.generate(101, 899, hint, "3.2");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("a_minus_b_within_thousand_base10_3_2")) { // Karl
            a_minus_b_within_thousand_base10_3_2 add = new a_minus_b_within_thousand_base10_3_2();
            results = add.generate(101, 899, hint, "3.2");
            results.addElement("1");
            results.addElement("abc");
        } //base10 Level 3.3
        else if (algo.equals("a_times_b_10_to_90_base10_3_3")) { // Karl
            a_times_b_10_to_90_base10_3_3 add = new a_times_b_10_to_90_base10_3_3();
            results = add.generate(10, 99, hint, "3.3");
            results.addElement("1");
            results.addElement("abc");
        } // *************************  LEVEL 4 *******************************************
        //algebra level 4.1
        else if (algo.equals("a_times_asManyAs_b_alg_4_1")) { // Karl
            a_times_asManyAs_b_alg_4_1 add = new a_times_asManyAs_b_alg_4_1();
            results = add.generate(1, 100, hint, "4.1");
            results.addElement("1");
            results.addElement("abc");
        } //algebra level 4.4
        else if (algo.equals("which_is_a_factor_of_alg_4_4")) { // Karl
            which_is_a_factor_of_alg_4_4 add = new which_is_a_factor_of_alg_4_4();
            results = add.generate(1, 100, hint, "4.4");
            results.addElement("1");
            results.addElement("abc");
        } //algebra level 4.5
        else if (algo.equals("sequence_of_numbers_alg_4_5")) { // Karl
            sequence_of_numbers_alg_4_5 add = new sequence_of_numbers_alg_4_5();
            results = add.generate(1, 100, hint, "4.5");
            results.addElement("1");
            results.addElement("abc");
        } //GENE START   
        //algebra 3_8
        else if (algo.equals("WordProblemPetStore_3_8")) { // Gene
            WordProblemPetStore_3_8 add = new WordProblemPetStore_3_8();
            results = add.generate(1, 50, hint, "3.8");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("InOutPlus_3_9")) { // Gene
            InOutPlus_3_9 add = new InOutPlus_3_9();
            results = add.generate(1, 50, hint, "3.9");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("InOutMultiply_3_9")) { // Gene
            InOutMultiply_3_9 add = new InOutMultiply_3_9();
            results = add.generate(1, 50, hint, "3.9");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("InOutPlus_4_0")) { // Gene
            InOutPlus_3_9 add = new InOutPlus_3_9();
            results = add.generate(1, 100, hint, "4.0");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("InOutMultiply_4_0")) { // Gene
            InOutMultiply_3_9 add = new InOutMultiply_3_9();
            results = add.generate(1, 100, hint, "4.0");
            results.addElement("1");
            results.addElement("abc");
        } else if (algo.equals("WordProblemMoneyMultiply_4_2")) { // Gene
            WordProblemMoneyMultiply_4_2 add = new WordProblemMoneyMultiply_4_2();
            results = add.generate(10, 900, hint, "4.2");
            results.addElement("1");
            results.addElement("abc");
        }else if (algo.equals("Money_WordProblem_multiStep")) { // Gene
            Money_WordProblem_multiStep add = new Money_WordProblem_multiStep();
            results = add.generate(1, 100, hint, "4.3");
            results.addElement("1");
            results.addElement("abc");
        }else if (algo.equals("sequence_of_numbers_alg_4_6")) { // Gene
            sequence_of_numbers_alg_4_5 add = new sequence_of_numbers_alg_4_5();
            results = add.generate(1, 150, hint, "4.6");
            results.addElement("1");
            results.addElement("abc");
        }else if (algo.equals("sequence_of_numbers_alg_4_7")) { // Gene
            sequence_of_numbers_alg_4_5 add = new sequence_of_numbers_alg_4_5();
            results = add.generate(1, 250, hint, "4.7");
            results.addElement("1");
            results.addElement("abc");
        }else if (algo.equals("sequence_of_numbers_alg_4_8")) { // Gene
            sequence_of_numbers_alg_4_5 add = new sequence_of_numbers_alg_4_5();
            results = add.generate(1, 300, hint, "4.8");
            results.addElement("1");
            results.addElement("abc");
        }else if (algo.equals("sequence_of_numbers_alg_4_9")) { // Gene
            sequence_of_numbers_alg_4_5 add = new sequence_of_numbers_alg_4_5();
            results = add.generate(1, 500, hint, "4.9");
            results.addElement("1");
            results.addElement("abc");
        }else if (algo.equals("MultiStepMath")) { // Gene
            MultiStepMath add = new MultiStepMath();
            results = add.generate(1, 100, hint, "5.0");
            results.addElement("1");
            results.addElement("abc");
        }else if (algo.equals("MultiStepMath_5_1")) { // Gene
            MultiStepMath add = new MultiStepMath();
            results = add.generate(1, 500, hint, "5.1");
            results.addElement("1");
            results.addElement("abc");
        }else if (algo.equals("MultiStepMath5_2")) { // Gene
            MultiStepMath5_2 add = new MultiStepMath5_2();
            results = add.generate(1, 500, hint, "5.1");
            results.addElement("1");
            results.addElement("abc");
        }else if (algo.equals("WriteOutHundredsPlace")) { // Gene
            WriteOutHundredsPlace add = new WriteOutHundredsPlace();
            results = add.generate(1, 500, hint, "5.3");
            results.addElement("1");
            results.addElement("abc");
        }else if (algo.equals("WriteOutThousandsPlace")) { // Gene
            WriteOutThousandsPlace add = new WriteOutThousandsPlace();
            results = add.generate(1, 500, hint, "5.3");
            results.addElement("1");
            results.addElement("abc");
        }




        return results;
    }

    public void LoadOptions() {
        DefaultComboBoxModel model;
        Vector options = new Vector();
        // options.addElement("addition 1 - 10");
        //  options.addElement("subtraction 1 - 10");
        ////    options.addElement("addition 1 - 100");
        //    options.addElement("subtraction 1 - 10");
        //    options.addElement("subtraction 1 - 100");
        //     options.addElement("multiply 1 - 10");
        options.addElement("---- START COUNTING LEVEL 1.1 ----");
        options.addElement("1+2+3=?");
        options.addElement("2+_=12");
        options.addElement("2+9=11 11-_=9");
        options.addElement("start@xandcountupbyy");
        options.addElement("start at x and count down by y");
        options.addElement("---- START COUNTING LEVEL 1.2 ----");
        options.addElement("1+2+3=? lvl_1_2");
        options.addElement("2+_=12 lvl_1_2");
        options.addElement("2+9=11 11-_=9 lvl_1_2");
        options.addElement("start@xandcountupbyy_lvl_1_2");
        options.addElement("start at x and count down by y_lvl_1_2");
        options.addElement("---- START COUNTING LEVEL 1.3 ----");
        options.addElement("67,68,69,_");
        options.addElement("67,_,69,70");
        options.addElement("---- START COUNTING LEVEL 1.4 ----");
        options.addElement("15=10+_");
        options.addElement("_<X");
        options.addElement("---- START COUNTING LEVEL 1.5 ----");
        options.addElement("72+20=?_level_1.5");
        options.addElement("What is x less than y?");
        options.addElement("What is x more than y?");
        options.addElement("x-y=?_level_1_5");
        options.addElement("---- START ALGEBRA LEVEL 1.1 ----");
        options.addElement("WordProb_Within20");
        options.addElement("WordProbMinusWithin20");
        options.addElement("---- START ALGEBRA LEVEL 1.2 ----");
        options.addElement("WordProbAnimalsAdd_1_2");
        options.addElement("WordProb_Money_Level_1_2");
        options.addElement("---- START ALGEBRA LEVEL 1.3 ----");
        options.addElement("A_PLUS_B_PLUS_C");
        options.addElement("A_Plus_blank_equal_c");
        options.addElement("---- START ALGEBRA LEVEL 1.4 ----");
        options.addElement("A_Minus_BLANK_Equals_C");
        options.addElement("---- START ALGEBRA LEVEL 1.5 ----");
        options.addElement("Start_At_x_CountUP_Y");
        options.addElement("Start_AT_x_CountDown_By_Y_1_5_Alg");
        options.addElement("---- START ALGEBRA LEVEL 1.6 ----");
        options.addElement("a_plus_b_equals_c_lvl_1_6_Alg");
        options.addElement("a_minus_b_equals_c_lvl_1_6_alg");
        options.addElement("Related_Facts_1_6_alg");
        options.addElement("---- START ALGEBRA LEVEL 1.7 ----");
        options.addElement("Which_Statement_True_Add_lvl_1_7");
        options.addElement("---- START ALGEBRA LEVEL 1.8 ----");
        options.addElement("C_equals_A_Plus_Blank_1_8_alg");
        options.addElement("A_minus_BLANK_equals_C_alg_1_8");
        options.addElement("---- START Base10 LEVEL 1.1 ----");
        options.addElement("Base10_1_2_3_space_lvl_1_1");
        options.addElement("---- START Base10 LEVEL 1.2 ----");
        options.addElement("---- START Base10 LEVEL 1.3 ----");
        options.addElement("WhichTrue_Greater_Less");
        options.addElement("---- START Base10 LEVEL 1.4 ----");
        options.addElement("A_Plus_b_equals_c_Base10_Lvl_1_4");
        options.addElement("---- START Base10 LEVEL 1.5 ----");
        options.addElement("WhatisXMoreThanY_lvl_1_5_Base10");
        options.addElement("---- START Base10 LEVEL 1.6 ----");
        options.addElement("SubtractMultiplesOfTen_BASE10_1_6");
        options.addElement("---------------------- START LEVEL 2 --------------------------");
        options.addElement("---- START Algebra LEVEL 2.1 ----");
        options.addElement("Alg_WordProblems_lvl2_1");
        options.addElement("---- START Algebra LEVEL 2.2 ----");
        options.addElement("A_Plus_b_equals_c_Alg_2_2");
        options.addElement("a_minus_blank_equals_c_Alg_2_2");
        options.addElement("blank_plus_b_equals_c_Alg_2_2");
        options.addElement("---- START Algebra LEVEL 2.3 ----");
        options.addElement("Alg_which_number_odd_even_2_3");
        options.addElement("Which_Number_Even_2_3");
        options.addElement("Number_Between_Alg_2_3");
        options.addElement("---- START Base10 LEVEL 2.2 ----");
        options.addElement("count_456_457_blank_Base10_2_2");
        options.addElement("count_246_blank_446_base10_2_2");
        options.addElement("count_230_blank_250_base10_2_2");
        options.addElement("count_330_335_blank_base10_2_2");
        options.addElement("---- START Base10 LEVEL 2.4 ----");
        options.addElement("blank_greater_than_b_base10_2_4");
        options.addElement("---- START Base10 LEVEL 2.5 ----");
        options.addElement("a_plus_b_equals_blank_Base10_2_5");
        options.addElement("a_minus_b_equals_blank_base10_2_5");
        options.addElement("---- START Base10 LEVEL 2.6 ----");
        options.addElement("a_plus_b_plus_c_Base10_2_6");
        options.addElement("a_plus_b_plus_c_plus_d_base10_2_6");
        options.addElement("---- START Base10 LEVEL 2.7 ----");
        options.addElement("a_plus_b_within_1000_base10_2_7");
        options.addElement("a_minus_b_within_1000_base10_2_7");
        options.addElement("---- START Base10 LEVEL 2.8 ----");
        options.addElement("minus_10_or_100_base10_2_8");
        options.addElement("plus_10_or100_base10_2_8");
        options.addElement("---- START Base10 LEVEL 2.9 ----");
        options.addElement("if_then_a_plus_blank_equals_c_base10_2_9");
        options.addElement("if_then_a_minus_blank_equals_c_base10_2_9");
        options.addElement("fact_family_within_100_base10_2_9");
        options.addElement("---------------------- START LEVEL 3 --------------------------");
        options.addElement("---- START Algebra Level 3.1 ---");
        options.addElement("how_many_rows_of_numbers_alg_3_1");
        options.addElement("which_number_sentence_alg_3_1");
        options.addElement("---- START Algebra Level 3.2 ---");
        options.addElement("WordProb_division_Alg_3_2");
        options.addElement("---- START Algebra LEVEL 3.4 ----");
        options.addElement("blank_times_b_equals_alg_3_4");
        options.addElement("a_equals_b_dividedby_blank_alg_3_4");
        options.addElement("---- START Algebra LEVEL 3.5 ----");
        options.addElement("commutative_multiplication_alg_3_5");
        options.addElement("associative_with_multiplication_alg_3_5");
        options.addElement("---- START Algebra LEVEL 3.6 ----");
        options.addElement("blank_times_b_equals_c_alg_3_6");
        options.addElement("blank_groups_of_b_equals_c_alg_3_6");
        options.addElement("---- START Algebra LEVEL 3.7 ----");
        options.addElement("a_dividedby_b_within100_alg_3_7");
        options.addElement("a_times_b_equals_alg_3_7");
        options.addElement("---- START Base10 LEVEL 3.1 ----");
        options.addElement("Round_to_nearest_10_base10_3_1");
        options.addElement("Round_to_nearest_100_base10_3_1");
        options.addElement("---- START Base10 LEVEL 3.2 ----");
        options.addElement("a_plus_b_within_thousand_base10_3_2");
        options.addElement("a_minus_b_within_thousand_base10_3_2");
        options.addElement("---- START Base10 LEVEL 3.3 ----");
        options.addElement("a_times_b_10_to_90_base10_3_3");
        options.addElement("---------------------- START LEVEL 4 --------------------------");
        options.addElement("---- START Algebra LEVEL 4.1 ----");
        options.addElement("a_times_asManyAs_b_alg_4_1");
        options.addElement("---- START Algebra LEVEL 4.4 ----");
        options.addElement("which_is_a_factor_of_alg_4_4");
        options.addElement("---- START Algebra LEVEL 4.5 ----");
        options.addElement("sequence_of_numbers_alg_4_5");

        //GENE START
        options.addElement("---- START Algebra LEVEL 3.8 ----");
        options.addElement("WordProblemPetStore_3_8");
        options.addElement("---- START Algebra LEVEL 3.9 ----");
        options.addElement("InOutPlus_3_9");
        options.addElement("InOutMultiply_3_9");
        options.addElement("---- START Algebra LEVEL 4.0 ----");
        options.addElement("InOutPlus_4_0");
        options.addElement("InOutMultiply_4_0");
        options.addElement("---- START Algebra LEVEL 4.2 ----");
        options.addElement("WordProblemMoneyMultiply_4_2");
         options.addElement("---- START Algebra LEVEL 4.3 ----");
        options.addElement("Money_WordProblem_multiStep");
 options.addElement("---- START Algebra LEVEL 4.6 ----");
        options.addElement("sequence_of_numbers_alg_4_6");
        options.addElement("---- START Algebra LEVEL 4.7---");
        options.addElement("sequence_of_numbers_alg_4_7");
        options.addElement("---- START Algebra LEVEL 4.8 ----");
        options.addElement("sequence_of_numbers_alg_4_8");
        options.addElement("---- START Algebra LEVEL 4.9 ----");
        options.addElement("sequence_of_numbers_alg_4_9");
         options.addElement("---- START Algebra LEVEL 5.0 ----");
        options.addElement("MultiStepMath");
         options.addElement("---- START Algebra LEVEL 5.1 ----");
          options.addElement("MultiStepMath_5_1");
          options.addElement("---- START Algebra LEVEL 5.1 ----");
          options.addElement("MultiStepMath5_2");
          options.addElement("---- START Algebra LEVEL 5.3 ----");
          options.addElement("WriteOutHundredsPlace");
          options.addElement("WriteOutThousandsPlace");
          

// ComboBox Items have gotten from Data Base initially.
        algoselect.setModel(new javax.swing.DefaultComboBoxModel(options));

    }

    public void Save(String location, Vector questions) {
        try {
            PrintWriter out = new PrintWriter(location);

            String question = "";
            String A = "";
            String B = "";
            String C = "";
            String D = "";
            String E = "";
            String Correct_Select = "";
            int qzid = Integer.parseInt(quizid.getText());
            String hint = "";
            String hintimg = "";
            String level = "";
            String subject = "";
            String subjecttype = "";
            String uid = "";
            String sid = "";
            String img = "";
            //generate sql code
            sqlcode = "INSERT INTO question_bank VALUES";
            for (int i = 0; i < questions.size(); i++) {
                String Raw_Row = questions.elementAt(i).toString();
                Raw_Row = Raw_Row.substring(1, Raw_Row.length() - 1);
                //  Raw_Row = Raw_Row.replaceAll("]", "");
                System.out.println(Raw_Row);

                StringTokenizer st = new StringTokenizer(Raw_Row, ",");
                //  while (st.hasMoreTokens()) {
                qzid = qzid++;
                int qid = qzid;
                try {
                    question = st.nextToken();
                    A = st.nextToken();
                    B = st.nextToken();
                    C = st.nextToken();
                    D = st.nextToken();
                    E = st.nextToken();
                    Correct_Select = st.nextToken();
                    //   st.nextToken(); QID goes here
                    hint = st.nextToken();
                    hintimg = st.nextToken();
                    level = st.nextToken();
                    subject = st.nextToken();
                    subjecttype = st.nextToken();
                    uid = st.nextToken();
                    sid = st.nextToken();
                    img = st.nextToken();
                } catch (Exception e) {
                }
                //            subjecttype = st.nextToken();
                if (i > 0) {
                    sqlcode = sqlcode + ",";
                }
                // }
                qid = qid + i;
                if (question.contains("~")) { //escape char for , 
                    question = question.replaceAll("~", ",");
                }
                hint = hint.replaceAll(">", ","); // custom escape char for commas 
                sqlcode = sqlcode + "("
                        + "'" + question + "',"
                        + "'" + A.trim() + "',"
                        + "'" + B.trim() + "',"
                        + "'" + C.trim() + "',"
                        + "'" + D.trim() + "',"
                        + "'" + E.trim() + "',"
                        + "'" + Correct_Select.trim() + "',"
                        + qid++ + ","
                        + "'" + hint.trim() + "',"
                        + "'" + hintimg.trim() + "',"
                        + "'" + level.trim() + "',"
                        + "'" + subject.trim() + "',"
                        + "'" + subjecttype.trim() + "',"
                        + uid.trim() + "," + sid.trim() + ","
                        + "''"
                        + ")";

                //  out.println(sqlcode);
            }
            sqlcode = sqlcode + ";";
            out.println(sqlcode);
            out.close();
            // Add save code here
            System.out.println(sqlcode);

        } catch (Exception e) {
            System.out.println(e);
        }

    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox Hint;
    private javax.swing.JComboBox algoselect;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JComboBox level_select;
    private javax.swing.JTextField question_sel;
    private javax.swing.JTextField quizid;
    private javax.swing.JTextField savelocation;
    // End of variables declaration//GEN-END:variables
}
