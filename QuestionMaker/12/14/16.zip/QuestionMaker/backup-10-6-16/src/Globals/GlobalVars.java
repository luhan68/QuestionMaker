/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Globals;

/**
 *
 * @author gene
 */
public class GlobalVars {
    //public static String Img_Location = "C:\\Users\\gene\\Desktop\\base_images\\";
    public static String Img_Location = "C:\\Users\\Doe\\Documents\\base_images\\";
    public static int counter = 0;
    public static String base_loc ="C:\\Users\\Doe\\Documents\\NetBeansProjects\\QuestionMaker\\";
}
