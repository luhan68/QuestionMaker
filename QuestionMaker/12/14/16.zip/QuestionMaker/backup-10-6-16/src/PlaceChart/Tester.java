/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package PlaceChart;

/**
 *
 * @author gene
 */
public class Tester {
    
    public static void main (String [] args){
        WordsToNumbersPlace words = new WordsToNumbersPlace();
       String val =  words.ConvertNumberToWords(315.22);
        System.out.println(val);
        
    }
    
}
